import React, { useEffect, useState } from 'react';
import axios from 'axios';

function HomeScreen() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/api/products')
      .then(res => setProducts(res.data))
      .catch(err => console.error(err));
  }, []);

  return (
    <div>
      <h1>Product List</h1>
      {products.map(p => (
        <div key={p._id}>
          <img src={p.image} alt={p.name} width="100" />
          <h2>{p.name}</h2>
          <p>₹ {p.price}</p>
          <p>{p.description}</p>
        </div>
      ))}
    </div>
  );
}

export default HomeScreen;
