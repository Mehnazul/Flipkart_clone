import React from 'react';
import HomeScreen from './screens/HomeScreen';

function App() {
  return <HomeScreen />;
}

export default App;
